package uz.eko.bolajon.app;

import uz.eko.bolajon.app.SplashActivity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.graphics.Typeface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class MainActivity extends  AppCompatActivity  { 
	
	
	private ScrollView vscroll_root;
	private LinearLayout linear_root_control_1;
	private LinearLayout linear_logo;
	private LinearLayout linear_dashboard_1;
	private LinearLayout linear_dashboard_2;
	private LinearLayout linear_root_control_2;
	private TextView textview_logo_1;
	private ImageView imageview_info;
	private CardView cardview_dashboard_1;
	private ImageView imageview_dashboard_1;
	private CardView cardview_dashboard_2;
	private ImageView imageview_dashbaord_2;
	private LinearLayout linear_dashboard_3;
	private LinearLayout linear_dashboard_4;
	private LinearLayout linear_round_radius_1;
	private TextView textview_dashboard_3;
	private CardView cardview_round_radius_1;
	private ImageView imageview3;
	private LinearLayout linear_round_radius_2;
	private TextView textview_dashboard_4;
	private CardView cardview_round_radius_2;
	private ImageView imageview4;
	
	private SharedPreferences splash_data;
	private Intent splash_intent = new Intent();
	private Intent hayvonlar_intent = new Intent();
	private Intent osimliklar_intent = new Intent();
	private Intent sozlamalar_intent = new Intent();
	private Intent topishmoqlar_intent = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll_root = (ScrollView) findViewById(R.id.vscroll_root);
		linear_root_control_1 = (LinearLayout) findViewById(R.id.linear_root_control_1);
		linear_logo = (LinearLayout) findViewById(R.id.linear_logo);
		linear_dashboard_1 = (LinearLayout) findViewById(R.id.linear_dashboard_1);
		linear_dashboard_2 = (LinearLayout) findViewById(R.id.linear_dashboard_2);
		linear_root_control_2 = (LinearLayout) findViewById(R.id.linear_root_control_2);
		textview_logo_1 = (TextView) findViewById(R.id.textview_logo_1);
		imageview_info = (ImageView) findViewById(R.id.imageview_info);
		cardview_dashboard_1 = (CardView) findViewById(R.id.cardview_dashboard_1);
		imageview_dashboard_1 = (ImageView) findViewById(R.id.imageview_dashboard_1);
		cardview_dashboard_2 = (CardView) findViewById(R.id.cardview_dashboard_2);
		imageview_dashbaord_2 = (ImageView) findViewById(R.id.imageview_dashbaord_2);
		linear_dashboard_3 = (LinearLayout) findViewById(R.id.linear_dashboard_3);
		linear_dashboard_4 = (LinearLayout) findViewById(R.id.linear_dashboard_4);
		linear_round_radius_1 = (LinearLayout) findViewById(R.id.linear_round_radius_1);
		textview_dashboard_3 = (TextView) findViewById(R.id.textview_dashboard_3);
		cardview_round_radius_1 = (CardView) findViewById(R.id.cardview_round_radius_1);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		linear_round_radius_2 = (LinearLayout) findViewById(R.id.linear_round_radius_2);
		textview_dashboard_4 = (TextView) findViewById(R.id.textview_dashboard_4);
		cardview_round_radius_2 = (CardView) findViewById(R.id.cardview_round_radius_2);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		splash_data = getSharedPreferences("splash_data", Activity.MODE_PRIVATE);
		
		linear_dashboard_1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				hayvonlar_intent.setClass(getApplicationContext(), HayvonlarActivity.class);
				startActivity(hayvonlar_intent);
			}
		});
		
		linear_dashboard_2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				osimliklar_intent.setClass(getApplicationContext(), OsimliklarActivity.class);
				startActivity(osimliklar_intent);
			}
		});
		
		linear_dashboard_3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				topishmoqlar_intent.setClass(getApplicationContext(), TopishmoqlarActivity.class);
				startActivity(topishmoqlar_intent);
			}
		});
		
		linear_dashboard_4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				sozlamalar_intent.setClass(getApplicationContext(), SozlamalarActivity.class);
				startActivity(sozlamalar_intent);
			}
		});
	}
	
	private void initializeLogic() {
		if (splash_data.getString("data", "").equals("")) {
			splash_intent.setClass(getApplicationContext(), SplashActivity.class);
			startActivity(splash_intent);
		}
		else {
			
		}
		_lightStatusbar();
		linear_dashboard_1.setElevation((float)2);
		linear_dashboard_2.setElevation((float)2);
		linear_dashboard_3.setElevation((float)2);
		linear_dashboard_4.setElevation((float)2);
		linear_dashboard_3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xFF3BC25E));
		linear_dashboard_4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)18, 0xFF175689));
		textview_logo_1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/times_new_roman_bold.ttf"), 0);
		textview_dashboard_3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/times_new_roman_bold.ttf"), 0);
		textview_dashboard_4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/times_new_roman_bold.ttf"), 0);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _lightStatusbar () {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		
		Window window = this.getWindow();window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS); window.setNavigationBarColor(Color.parseColor("#ffffff"));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}